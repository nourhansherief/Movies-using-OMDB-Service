class ArticlesController < ApplicationController
  before_action :set_article
  before_action :set_articles

  def index
    
  end

  def create
    @message = 'Please fix these ' 
    if @article.save 
      @message = 'Articale Added'
      @article = Article::new
    end
    render :index 
  end

  private

    def branch_params
      params.require(:article).permit(:title, :content) if params[:article]
    end

    def set_article
      @article = Article.new(branch_params.to_h)
    end

    def set_articles
      @articles = Article::all()
    end
end
