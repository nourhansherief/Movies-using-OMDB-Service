class User < ApplicationRecord
  def full_name
    return "#{first_name} #{last_name}" unless last_name.nil?
    ''
  end
end
