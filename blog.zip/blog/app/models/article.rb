class Article < ApplicationRecord
  validates :content, :title, presence: true
end
