Rails.application.routes.draw do
  resources :articles
end
